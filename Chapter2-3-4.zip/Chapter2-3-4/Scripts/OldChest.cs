﻿using UnityEngine;
using System.Collections;

public class OldChest : MonoBehaviour {
    public Sprite OpenChest;
    public Sprite ClosedChest;
    public GameObject coin;

    private bool wasOpen;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player" &&  !wasOpen)
        {
            GetComponent<SpriteRenderer>().sprite = OpenChest;
            GetComponent<AudioSource>().Play();
            wasOpen = true;
            StartCoroutine(SpawnCoins());
        }
    }

    // Coroutine for spawning the coins out of the chest
    IEnumerator SpawnCoins()
    {
        int coins = 10;
        GameObject go;
        Rigidbody2D rb;
        while (coins > 0)
        {
            --coins;
            go = Instantiate(coin,transform.position+ new Vector3(0f,0.5f,0f),Quaternion.identity,transform) as GameObject;
            rb = go.GetComponent<Rigidbody2D>();
            rb.AddRelativeForce(new Vector2( Random.Range(-1f,1f)*250f, 250f ));
            go = null;
            rb = null;
            yield return new WaitForSeconds(0.25f);

        }
        
    }

    // We call this function from the parallax component, using a SendMessage method
    void CloseBox()
    {
        wasOpen = false;
        GetComponent<SpriteRenderer>().sprite = ClosedChest;
    }

}
