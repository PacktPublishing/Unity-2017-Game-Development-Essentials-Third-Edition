﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityStandardAssets.CrossPlatformInput;
using System.Collections;

namespace UnityStandardAssets._2D
{
    [RequireComponent(typeof(PlatformerCharacter2D))]
    public class Platformer2DCustomController : Platformer2DUserControl
    {
        public FreeParallax parallax;
        static private PlatformerCharacter2D m_Character;
        static private bool m_Jump;

        private int health;
        private int score;
        private float elapsedTime;
        private float timeLimit = 150f; // 150 seconds limit to finish the level

        // Boolean indicating when the class should receive input
        private bool gameInactive;
        // UI elements for holding healt, score and time
        public GameObject healthLabel;
        public GameObject scoreLabel;
        public GameObject timeLabel;
        public GameObject StartLabel;
        public GameObject EndLabel;

        // Final UI objects with particles for the end of the game
        public GameObject wonObject;
        public GameObject lostObject;

        private void Awake()
        {
            score = 0;
            health = 100;
            m_Character = GetComponent<PlatformerCharacter2D>();
        }

        // We use System.Collections so we can use Coroutines, Start() automated function can be threated as a coroutine
        IEnumerator Start()
        {
            gameInactive = true;
            // Wait 2 seconds to start the game
            yield return new WaitForSeconds(3f);
            StartLabel.SetActive(false);
            gameInactive = false;
        }

        // checking the inputs in the FixedUpdate function for better results on different machines
        private void FixedUpdate()
        {
            bool crouch = false;
            float h=0;

            // Read the inputs for restarting the game or the inputs for playing
            if (gameInactive)
            {
                if ( (CrossPlatformInputManager.GetButtonDown("Fire1") || CrossPlatformInputManager.GetButtonDown("Jump") ) && !StartLabel.activeSelf )
                {
                    // Restart the level 
                    SceneManager.LoadScene( SceneManager.GetActiveScene().name );
                }
            }
            else
            {
                crouch = Input.GetKey(KeyCode.LeftShift);
                h = CrossPlatformInputManager.GetAxis("Horizontal");
            }

            // If it exists a parallax object, set its speed accordingly
            if (parallax != null)
            {
                parallax.Speed = -h * parallax.BasicSpeedMultiplier;
                // Reduce the speed if crouching by the crouchSpeed multiplier
                parallax.Speed = (crouch ? parallax.Speed * m_Character.m_CrouchSpeed : parallax.Speed);
            }

            // Pass all parameters to the character control script.
            m_Character.Move(h, crouch, m_Jump);
            m_Jump = false;
        }

        // Update is called once per frame
        void Update()
        {
            // Process the inputs, time and game logic, if game is active
            if (!gameInactive)
            {
                // Calculate elapsed time
                elapsedTime += Time.deltaTime;
                // Update time display
                timeLabel.GetComponent<Text>().text = "Time:" + Mathf.RoundToInt(timeLimit - elapsedTime);

                // Check game logic
                if (timeLimit - elapsedTime < 0)
                {
                    if (score >= 1000) wonObject.SetActive(true); else lostObject.SetActive(true);
                    gameInactive = true;
                    EndLabel.SetActive(true);
                }
                // If score 1000 is reach, win the game
                if (score >= 1000) { wonObject.SetActive(true); gameInactive = true; EndLabel.SetActive(true); }
                // If health is equal or minor than 0 is game over
                if (health <= 0) { lostObject.SetActive(true); gameInactive = true; EndLabel.SetActive(true); }

                if (!m_Jump)
                {
                    // Read the jump input in Update so button presses aren't missed.
                    m_Jump = CrossPlatformInputManager.GetButtonDown("Jump");
                }
            }

        }

        // Method called by the coin when collected
        void AddCoins(int quantity)
        {
            score += quantity;
            scoreLabel.GetComponent<Text>().text = "Score: " + score;
        }


        // Check collision with rolling stones
        void OnCollisionEnter2D(Collision2D other)
        {
            // You can tweak the magnitude comparison to make the stones less or more hurting
            if (other.relativeVelocity.magnitude > 3 && other.gameObject.layer == 11) // 11 is the id of MovingObstacle layer
            {
                other.gameObject.GetComponent<AudioSource>().Play();
                health -= 10;
                healthLabel.GetComponent<Text>().text = "Health: " + health;
            }
  
        }

    }
}

