﻿using UnityEngine;
using System.Collections;

public class Collectible2D : MonoBehaviour {

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            other.gameObject.SendMessage("AddCoins", 10);
            GetComponent<AudioSource>().Play();
            //this.gameObject.SetActive(false);
            this.GetComponents<Collider2D>()[0].enabled = false;
            this.GetComponents<Collider2D>()[1].enabled = false;
            Destroy(this.gameObject, GetComponent<AudioSource>().clip.length);
        }
    }


}
