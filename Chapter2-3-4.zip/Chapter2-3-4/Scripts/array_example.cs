﻿using UnityEngine;

public class array_example : MonoBehaviour {

    public GameObject[] enemies;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
