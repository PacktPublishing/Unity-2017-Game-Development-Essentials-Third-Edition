﻿using UnityEngine;
using System.Collections; // This is needed to bring in coroutines support

public class GoldChest : MonoBehaviour {
    public Sprite OpenChest; // A reference of the open chest graphic
    public Sprite ClosedChest; // A reference of the closed chest graphic
    public GameObject coin; // The reference to the prefab of the collectible to spawn off

    private bool wasOpen; // Private boolean that determines if this chest was already opened before to re-generate (see FreeParallax.cs modifications) 

    // Trigger collision detection, if the player touches the chest
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player" &&  !wasOpen)
        {
            GetComponent<SpriteRenderer>().sprite = OpenChest;
            GetComponent<AudioSource>().Play();
            wasOpen = true;
            // Start our first coroutine ;-)
            StartCoroutine(SpawnCoins());
        }
    }

    // Coroutine for spawning the coins out of the chest
    IEnumerator SpawnCoins()
    {
        int coins = 10;
        GameObject go;
        Rigidbody2D rb;
        while (coins > 0)
        {
            --coins;
            go = Instantiate(coin,transform.position+ new Vector3(0f,0.5f,0f),Quaternion.identity,transform) as GameObject;
            rb = go.GetComponent<Rigidbody2D>();
            rb.AddRelativeForce(new Vector2( Random.Range(-1f,1f)*250f, 250f ));
            go = null;
            rb = null;
            yield return new WaitForSeconds(0.25f);

        }
        
    }

    // We call this function from the FreeParallax component, using a SendMessage method, when the Chest need to be redrawn as a new one
    void CloseBox()
    {
        wasOpen = false;
        GetComponent<SpriteRenderer>().sprite = ClosedChest;
    }

}
