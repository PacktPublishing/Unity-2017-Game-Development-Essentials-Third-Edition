﻿using UnityEngine;
using System.Collections;

public class StoneSpawner : MonoBehaviour {

    public GameObject stonePrefab; // The stone prefab we want to spawn from here

    // This standard event method will be called whenever this object is rendered
	IEnumerator OnBecameVisible () {
        yield return new WaitForEndOfFrame();
        Instantiate(stonePrefab, transform.position, Quaternion.identity);
    }

}
