﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class Shooter : MonoBehaviour {
	
	public Rigidbody bullet;
	public float power = 1500f;
	public float moveSpeed = 2f;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		float h = Input.GetAxis("Horizontal") * Time.deltaTime * moveSpeed;
		float v = Input.GetAxis("Vertical") * Time.deltaTime * moveSpeed;
		transform.Translate(h, 0, v);

		if(Input.GetButtonUp("Fire1")){
			Rigidbody instance = Instantiate(bullet, transform.position+new Vector3(.5f,1f,0), transform.rotation) as Rigidbody;
			Vector3 fwd = transform.TransformDirection(Vector3.forward);
			instance.AddForce(fwd * power);
		}

		if(Input.GetButtonUp("Cancel")){
            //Application.Quit();
			SceneManager.LoadScene(SceneManager.GetActiveScene().name);
		}
	}
}
